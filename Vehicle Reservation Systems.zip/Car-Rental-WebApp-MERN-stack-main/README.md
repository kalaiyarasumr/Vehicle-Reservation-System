# Car-Rental-WebApp-MERN-stack

+ It is a Rent a car website where Customers can book the cars by paying through Stripe.
+ Admin can see the bookings and can manage the cars.
+ If a car is booked for a time span no other customer can book the same car on same time span.

## Technologies Used

### Frontend
+ ReactJs
+ Bootstrap
+ antd
+ Redux Toolkit

### Backend
+ NodeJs
+ ExppressJs
+ Mongoose

### Database
+ MongoDB


## Live Link
https://thankful-purse-duck.cyclic.app/
