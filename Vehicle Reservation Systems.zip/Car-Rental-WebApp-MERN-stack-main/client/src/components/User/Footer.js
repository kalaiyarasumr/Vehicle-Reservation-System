import React from 'react'

const Footer = () => {
  return (
    <footer className='text-center bg-dark text-white'>
      @Book Your Car
    </footer>
  )
}

export default Footer
